import { Component, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Api } from '../../services/api';

interface TeamMember {
  name: string;
  email: string;
  role: string;
  status: string;
  lastActive: string;
  avatarClass: string;
}

@Component({
  selector: 'app-users',
  imports: [MatButtonModule, MatTableModule,MatPaginatorModule],
  templateUrl: './users.html',
  styleUrl: './users.css',
})
export class Users {
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol','action'];
  dataSource = new MatTableDataSource<any>([]);

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private api:Api){}

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  ngOnInit(){
    // this.getUsers()
  }

  getUsers(){
    this.api.get('/users').subscribe({
      next:(res:any)=>{
        console.log('users data api:::',res)
      }
    })
  }


 

}




